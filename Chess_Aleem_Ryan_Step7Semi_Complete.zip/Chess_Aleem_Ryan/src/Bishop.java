import javax.swing.*;

public class Bishop extends Piece {
    public Bishop(boolean color) {
        whitePiece = color;
        pieceType = "Bishop";

        if (whitePiece) {
            chessPiece = new ImageIcon("wbishop.gif");
        } else {
            chessPiece = new ImageIcon("bbishop.gif");
        }
    }
    public boolean canMove(int startx, int starty, int endx, int endy){
        //calculate the absolute difference for coordinates
        int kx=Math.abs(endx-startx);
        int ky=Math.abs(endy-starty);
        //Check id the move is valid on bishops diagonal movement
        if (kx==ky) {
            //calculate the direction of movement
            int kx2 = Integer.compare(endx, startx);
            int ky2 = Integer.compare(endy, starty);
            //Set the initial coordinates to the addition of direction & difference of movement
            int initialX = startx + kx2;
            int initialY = starty + ky2;
            //Check if there are pieces in the way
            while (initialX !=endx || initialY != endy){
                if (Chess.position[initialX][initialY]!=null){
                    return false;// if there are pieces in the way move is invalid
                }
                // move o the next coordinate in direction
                initialX += kx2;
                initialY += ky2;
            }
            return true;//If there are no pieces then true valid move
        }
        return false;//if the move is not a diagonal line then move invalid
    }
}
