import javax.swing.*;
import java.awt.*;

public class BoardComponent extends JComponent {
    public void paintComponent(Graphics g){
        for (int x=0; x<8; x++){
            for (int y=0; y<8; y++){
                if((x%2==0 && y%2==0)||(y%2==1&&x%2==1)){
                  g.setColor(new Color(233,174,95));
                  g.fillRect(x*Chess.tileSize,y*Chess.tileSize,Chess.tileSize,Chess.tileSize);
               }
                else{
                    g.setColor(new Color(177,113,24));
                    g.fillRect(x*Chess.tileSize,y*Chess.tileSize,Chess.tileSize,Chess.tileSize);
                }
                if (Chess.position[x][y]!=null){
                    Chess.position[x][y].drawPiece(x*Chess.tileSize,y*Chess.tileSize, g);
                }

           }
        }
    }
}