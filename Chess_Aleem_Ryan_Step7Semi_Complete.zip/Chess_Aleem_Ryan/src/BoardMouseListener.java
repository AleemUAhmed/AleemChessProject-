import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class BoardMouseListener implements MouseListener{
    int startx;
    int starty;
    int endx;
    int endy;

    @Override
    public void mousePressed(MouseEvent e) {
        //get the initial start position
        int x = e.getX() / Chess.tileSize;
        int y = e.getY() / Chess.tileSize;
        //check if the there is no chess piece, if there is return
        if (Chess.position[x][y]==null) {
            return;
        }
        //keeps within bounds of the board
        if (x<0||x>7||y<0||y>7){
            return;
        }
        //if there is a piece that Chess.computer.computerEndyist at that tile then store into startx and starty
        //there is a piece that Chess.computer.computerEndyist on that tile
        if (Chess.position[x][y]!=null){
            startx=x;
            starty=y;
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //get the intial end position
        int x = e.getX() / Chess.tileSize;
        int y = e.getY() / Chess.tileSize;
        //keeps within bounds of the board same code
        if (x < 0 || x > 7 || y < 0 || y > 7) {
            return;
        }
        //if the startx and initial x endpoint and starty and initial y end point's position is the same then return
        if (startx == x && starty == y) {
            return;
        }
        //if chess position is not white aka a black piece then return and do not move that piece
        if (!Chess.position[startx][starty].whitePiece) {
            return;
        }
        //turn initial end points into final end points after all if statements are good to bypass
        endx = x;
        endy = y;

        //check if the move is valid for the piece
        if (Chess.position[startx][starty].canMove(startx, starty, endx, endy)) {
            //move the piece
            Chess.position[endx][endy] = Chess.position[startx][starty];
            Chess.position[startx][starty] = null;

            //repaint the board
            Chess.chessBoard.repaint();
        }
        //computer player move
        makeComputerMove();
    }
        private void makeComputerMove () {
            //computer player
            while (true) {
                int computerStartx = (int) (Math.random() * 8);
                int computerStarty = (int) (Math.random() * 8);
                int computerEndx = (int) (Math.random() * 8);
                int computerEndy = (int) (Math.random() * 8);

                if (Chess.position[computerStartx][computerStarty] == null) {
                    continue;
                }

                if (computerStartx == computerEndx && computerStarty == computerEndy) {
                    continue;
                }

                if (Chess.position[computerStartx][computerStarty].whitePiece) {
                    continue;
                }
                if (Chess.position[computerEndx][computerEndy]!=null && !Chess.position[computerEndx][computerEndy].whitePiece) {
                    continue;
                }

                //check if the move is valid for the piece
                if (Chess.position[computerStartx][computerStarty].canMove(computerStartx, computerStarty, computerEndx, computerEndy)) {
                    //move the piece
                    Chess.position[computerEndx][computerEndy] = Chess.position[computerStartx][computerStarty];
                    Chess.position[computerStartx][computerStarty] = null;

                    //repaint the board
                    Chess.chessBoard.repaint();
                    break;
                }
            }

    }

    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
    public void mouseClicked(MouseEvent e){
    }
}
