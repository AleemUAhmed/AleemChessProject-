import javax.swing.*;
public class Chess {
    //initialize final tile size
    public static final int tileSize= 44;
    //initialize final board size
    public static final int boardSize= tileSize*8;
    public static Piece[][] position = new Piece[8][8];

    public static BoardComponent chessBoard;

    public static void main(String[] args) {
        //draw black knight
        position[1][0] = new Knight(false);
        position[6][0] = new Knight(false);
        //draw white knight
        position[1][7] = new Knight(true);
        position[6][7] = new Knight(true);
        //draw black bishop
        position[2][0] = new Bishop(false);
        position[5][0] = new Bishop(false);
        //draw white knight
        position[2][7] = new Bishop(true);
        position[5][7] = new Bishop(true);
        //draw black Rook
        position[0][0] = new Rook(false);
        position[7][0] = new Rook(false);
        //draw white rook
        position[0][7] = new Rook(true);
        position[7][7] = new Rook(true);
        //draw white king
        position[4][7]=new King(true);
        //draw black king
        position[4][0]=new King(false);
        //draw white queen
        position[3][7]=new Queen(true);
        //draw black queen
        position[3][0]=new Queen(false);
        //draw pawns
        for (int i=0; i<8; i++){
            position[i][1]=new Pawn(false);
            position[i][6]=new Pawn(true);
        }

        //creates a new window
        JFrame frame = new JFrame();
        //closes the window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set size in best dimension from trial and error
        frame.setSize(boardSize+16,boardSize+39);

        //Creates the graphic object
        chessBoard= new BoardComponent();
        //adds the object to the window
        frame.add(chessBoard);


        //Create the Mouse action object
        BoardMouseListener chessMouse=new BoardMouseListener();
        chessBoard.addMouseListener(chessMouse);


        //last line of code to set the window visible
        frame.setVisible(true);
    }
}