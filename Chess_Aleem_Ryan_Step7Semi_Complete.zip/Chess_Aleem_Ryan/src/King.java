import javax.swing.*;

public class King extends Piece {
    public King(boolean color) {
        whitePiece = color;//set color of King piece
        pieceType = "King";//set the tyoe of the piece as "King"
        //set the Image Icon for white king and black king
        if (whitePiece) {
            chessPiece=new ImageIcon("wking.gif");
        } else {
            chessPiece = new ImageIcon("bking.gif");
        }

    }
    //limit kings move to one space square only
    public boolean canMove(int startx, int starty, int endx, int endy){
        //calculate the absolute difference of the coordinates
        int kx=Math.abs(endx-startx);
        int ky=Math.abs(endy-starty);

        //check if move can go one tile from any direction
        if ((kx==1 && ky==0) || (kx==0 && ky==1) || (kx==1 && ky==1) ){
            return true;//if the move is one tile horizontally, vertically, or diagonally, it is valid
        }
        return false;//If the move does not move on tile in any direction then it is invalid
    }
}
