import javax.swing.*;

public class Knight extends Piece{
    public Knight(boolean color) {
        whitePiece = color;//set color to white
        pieceType = "Knight";//set type to "Knight"
        //Set the Image Icon to either black or white gif
        if (whitePiece) {
            chessPiece = new ImageIcon("wknight.gif");
        } else {
            chessPiece = new ImageIcon("bknight.gif");
        }
    }
    //limit the moves of knight to L shape
    public boolean canMove(int startx, int starty, int endx, int endy){
        //calc the abs difference in the coordinates like king
        int kx=Math.abs(endx-startx);
        int ky=Math.abs(endy-starty);

        //check if move is L Shape or two tiles horizontally and one vertically
        //or 1 tile horizontally and 2 vertically
        if ((kx==2 && ky==1) || (kx==1 && ky==2)){
            return true;//If the move is an L shape return true and it's valid
        }
        return false;//If move is not L then return false as it is invalid
    }
}
