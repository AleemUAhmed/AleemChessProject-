import javax.swing.*;

public class Pawn extends Piece{
    private boolean firtMove;
    public Pawn (boolean color){
        whitePiece=color;
        pieceType="Pawn";
        firtMove = true; // set the variable firstMove to true initially
        if (whitePiece){
            chessPiece=new ImageIcon("wpawn.gif");
        }
        else {
            chessPiece= new ImageIcon("bpawn.gif");
        }
    }
    //the move would be start of 2 but then do as normal for forward and kill diagonally
    public boolean canMove(int startx, int starty, int endx, int endy) {
        //calc the difference in coordinates
        int kx = endx - startx;
        int ky = endy - starty;
        if (whitePiece) {
            // White pawn can move forward one square
            if (ky == -1 && kx == 0 && Chess.position[endx][endy] == null) {
                firtMove = false; // Set firstMove to false after the first move
                return true;
            }
            // White pawn can move forward two squares on its first move
            if (firtMove && ky == -2 && kx == 0 && Chess.position[endx][endy] == null && Chess.position[endx + 1][endy] == null) {
                firtMove = false; // Set firstMove to false after the first move
                return true;
            }
            // White pawn can capture diagonally
            if (ky == -1 && Math.abs(kx) == 1 && Chess.position[endx][endy] != null && !Chess.position[endx][endy].whitePiece) {
                firtMove = false; // Set firstMove to false after the first move
                return true;
            }
        } else {
            // Black pawn can move forward one square
            if (ky == 1 && kx == 0 && Chess.position[endx][endy] == null) {
                firtMove = false; // Set firstMove to false after the first move
                return true;
            }
            // Black pawn can move forward two squares on its first move
            if (firtMove && ky == 2 && kx == 0 && Chess.position[endx][endy] == null && Chess.position[endx - 1][endy] == null) {
                firtMove = false; // Set firstMove to false after the first move
                return true;
            }
            // Black pawn can capture diagonally
            if (ky == 1 && Math.abs(kx) == 1 && Chess.position[endx][endy] != null && Chess.position[endx][endy].whitePiece) {
                firtMove = false; // Set firstMove to false after the first move
                return true;
            }

        }
        return false;//if the move is not valid based on the pawn's movement
    }
}

