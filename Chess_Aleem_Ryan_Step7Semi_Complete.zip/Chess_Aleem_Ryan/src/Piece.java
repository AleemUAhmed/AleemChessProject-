import javax.swing.*;
import java.awt.*;

public abstract class  Piece {
    public ImageIcon chessPiece; //variable to store color
    public boolean whitePiece;//variable to store the Image Icon

    public String pieceType;//variable to store piece type

    public void drawPiece(int x, int y, Graphics g){
        g.drawImage(chessPiece.getImage(),x,y,null);
    }

    //Abstract method to check if a move is valid
    public abstract boolean canMove(int startx, int starty, int endx, int endy);
}
