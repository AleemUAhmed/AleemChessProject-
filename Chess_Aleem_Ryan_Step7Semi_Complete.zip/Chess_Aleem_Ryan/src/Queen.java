import javax.swing.*;

public class Queen extends Piece{
    public Queen(boolean color) {
        whitePiece = color; //Set the color of the Queen piece
        pieceType = "Queen";// Set the type of piece as "Queen"

        if (whitePiece) {
            chessPiece = new ImageIcon("wqueen.gif"); // set the Image Icon for the white queen
        } else {
            chessPiece = new ImageIcon("bqueen.gif");// set the Image Icon for the white queen
        }
    }
    public boolean canMove(int startx, int starty, int endx, int endy){
        int kx=Math.abs(endx-startx);//Calc abs value difference of x- coordinates
        int ky=Math.abs(endy-starty);//Calc abs value difference of x- coordinates
        //Checks if the move is diagonal or straight
        if (startx == endx || starty == endy || kx==ky) {
            int kx2 = Integer.compare(endx, startx);//get the direction of movement in x-axis
            int ky2 = Integer.compare(endy, starty);//get the direction of movement in y-axis
            //sets initial coordinates to the starting coordinates + direction
            int initialX = startx + kx2;
            int initialY = starty + ky2;
            //checks if any pieces in the Queen's way
            while (initialX != endx || initialY != endy) {
                if (Chess.position[initialX][initialY] != null) {
                    return false;//If there is a piece in the path, the move is invalid
                }
                //move to the next coordinates in the direction
                initialX += kx2;
                initialY += ky2;
            }
            return true;//if there are no pieces in path, the move is valid

    }
        return false;//if the movie is not along a straight or diagonal line it is not valid
}
}
