import javax.swing.*;

public class Rook extends Piece{
    public Rook (boolean color) {
        whitePiece = color;//set color to white
        pieceType = "Rook";//set type to "Rook"
        //Set the Image Icon to either black or white gif
        if (whitePiece) {
            chessPiece=new ImageIcon("wrook.gif");
        }
        else {
            chessPiece = new ImageIcon("brook.gif");
        }
    }
    //Limit the movement to horizontal and vertical
    public boolean canMove(int startx, int starty, int endx, int endy) {
        //calc the abs value difference of the coordinates
        int kx=Math.abs(endx-startx);
        int ky=Math.abs(endy-starty);
        // Check if move is straight horizontally and vertically
        if (startx == endx || starty == endy) {
            //calculate the direction of the coordinates
            //Integer.compare= the value 0 if x == y; a value less than 0 if x < y; and a value greater than 0 if x > y
            int kx2 = Integer.compare(endx, startx);
            int ky2 = Integer.compare(endy, starty);
            //Set the coordinates to starting + direction
            int initialX = startx + kx2;
            int initialY = starty + ky2;
            //Check if there are any piece in the path of the Rook
            while (initialX != endx || initialY != endy) {
                if (Chess.position[initialX][initialY] != null) {
                    return false;//If there is a piece in the way then return false
                }
                //move to the coordinates in the direction
                initialX += kx2;
                initialY += ky2;
            }
            return true;//if there are no piece in the path, the move is valid
        }
        return false;//if the move is not straight horizontally or vertically the move is invalid
    }
}